<?php
/**
 * Created by PhpStorm.
 * User: Amit
 * Date: 2/11/2016
 * Time: 6:00 PM
 */
?>
<div class="col-md-13 picture">
    <a href="http://lpsashokvihar.com/lps-admin/assets/uploads/calendar/monthly_calendar.jpg" title="Important Day and Dates in this Month" class="fancybox"
       rel="gallery1">
        <span class="photo_icon"></span>
        <img src="http://lpsashokvihar.com/lps-admin/assets/uploads/calendar/monthly_calendar.jpg" alt="" class="img-responsive">
    </a>
</div>
<strong>Important Day and Dates in this Month</strong>

<!--<a href="all-courses.php" title="All courses">
<img src="img/banner.jpg" alt="Banner" class="img-rounded img-responsive">
</a>-->